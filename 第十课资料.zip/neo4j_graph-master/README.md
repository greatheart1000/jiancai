# neo4j_graph


1、先执行import_data.py脚本，把company_data下面的数据导入到neo4j

2、执行gnn/saint.py脚本进行节点分类

3、company.csv文件是每个节点的属性